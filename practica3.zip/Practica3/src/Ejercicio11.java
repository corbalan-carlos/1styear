
public class Ejercicio11 {

	public static void main(String[] args) {
	System.out.print("Este programa muestra mis iniciales en pantalla\n");
	banner();
	}
	static void banner() {
		System.out.print(
				  "   CCCCC    CCCCC     A      \n"
				+ "  C   	  C          A A    \n"
				+ " C   	 C          A   A   \n"
				+ " C   	 C         A  A  A  \n"
				+ "  C   	  C  	  A       A \n"
				+ "   CCCCC   CCCCC A         A\n"
		);
	}
	
}
